#include <stdio.h>
#include <stdlib.h>

// Problem 1


// Problem 2
long decode2 (long x, long y, long z) {
  // implement this
  return 2; // replace this with appropriate return statement
}

// Problem 3
long loop(long x, int n){

  // fill in this function
  

  return 0; // replace this with appropriate return statement
}

int main(){


  return 0;
}
