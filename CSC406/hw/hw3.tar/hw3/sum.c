int sum(int n){

  int i=0;
  int s=0;
  for(int i=0; i<= n; i++){
    s=s+i;
  }

  printf("The sum of first %d numbers is %d.\n", n,s);
}
