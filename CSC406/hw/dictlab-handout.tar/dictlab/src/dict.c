#include <stdlib.h>
#include <string.h>
#include "dict.h"

typedef struct dict_list {
    char* key;
    char* val;
    struct dict_list* next;
} dict_list_t;

typedef struct dict {
    dict_list_t* head;
    size_t size;
} dict_t;


dict_t* dict_create () {
  return NULL;
}

void dict_put (dict_t* dict, const char* key, const char* val) {
}

char* dict_get (const dict_t* dict, const char* key) {
  return NULL;
}

void dict_del (dict_t* dict, const char* key) {
}

size_t dict_size (const dict_t* dict) {
  return 0u;
}

void dict_clear (dict_t* dict) {
}

void dict_destroy (dict_t* dict) {
}

void dict_apply (const dict_t* dict, const dict_apply_fun_t fun, void* arg) {
}
