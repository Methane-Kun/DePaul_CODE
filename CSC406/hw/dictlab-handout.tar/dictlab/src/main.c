#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dict.h"

#define error(args...) do { fprintf (stderr, args); exit (1); } while (0)

char* readline (FILE* f);

int main (int argc, char** argv) {
  dict_t* dict = dict_create ();

  dict_destroy (dict);
}

#define BUFLEN 1024

char* readline (FILE* f) {
  char*  buf = NULL;
  size_t alloc_len = 0;
  ssize_t pos = -1;

  while (1) {
    int c = fgetc (f);

    if (c == EOF)
      return buf;
    ++pos;
    if (alloc_len <= pos) { // Reading one more char, and no more space.
      alloc_len += BUFLEN;
      buf = realloc (buf, alloc_len);
    }
    if (c == (int) '\n') {
      buf[pos] = 0;
      return buf;
    }
    buf[pos] = (char) c;
  }

  return buf;
}
