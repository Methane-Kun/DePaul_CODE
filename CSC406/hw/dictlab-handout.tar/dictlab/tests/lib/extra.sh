#!/bin/zsh -f

echook() {
    echo -ne '\e[1m\e[38;5;77m[OK]\e[0m ' >&2
    echoindent 5! "$@"
}

echoko() {
    echo -ne '\e[1;91m[KO]\e[0m ' >&2
    echoindent 5! "$@"
}

echoto() {
    echo -ne '\e[1;91m[TO]\e[0m ' >&2
    echoindent 5! "$@"
}

echomm() {
    echo -ne '\e[1;91m[MM]\e[0m ' >&2
    echoindent 5! "$@"
}

echopart () {
    echo -ne "\e[1m\e[30;47m" >&2
    ## For main header, fill the line.
    [[ $1 =~ '^\* ' ]] && printf '%*s\r' $COLUMNS
    echoindent -n "$@"
    echo -ne "\e[0m" >&2
    echoindent ""
}

echoscore () {
    echo -ne '\e[1m\e[38;5;255m\e[48;5;21m' >&2
    printf '%*s\r' $COLUMNS
    echoindent -n "$1"
    echo -ne "\e[0m" >&2
    echoindent "  $2  "
}

echosubscore () {
    echo -ne '\e[1m\e[38;5;255m\e[48;5;21m' >&2
    echoindent -n "$1"
    echo -ne "\e[0m" >&2
    echoindent "  $2  "
}


SPACES='              '
echoindent  () {
    case $1; in
        -n) # Don't mess with it.
            echo "$@" >&2
            ;;
        [0-9]) ## Indent by that amount
            indent=$1
            (( indent-- ))
            shift
            echo "$@" | sed "s/^/$SPACES[1,indent]/" | fmt -cts >&2
            ;;
        [0-9]!) ## Indent by that amount, but start at point.
            indent=${1[1]}
            (( indent-- ))
            shift
            echo "$@" | sed "s/^/$SPACES[1,indent]/" | fmt -cts | sed '1s/.\{'$indent'\}//' >&2
            ;;
        *)
            echo "$@" | fmt -cts >&2
    esac
}

wait_a_bit () {
    echo -n "Type Ctrl-C to kill the driver... "
    for i in {5..1}; do
        echo -n "$i "
        sleep 1
    done
    echo ""
}

check_agreement () {
    if ! [[ -e .agreement-accepted ]]; then
        cat <<EOF
                 =============================================
                           ACADEMIC INTEGRITY NOTICE
                               appears only once
                 =============================================

This is an  individual assignment.  Your submission will be  compared to that of
all your peers and with publicly available submissions using dedicated software.
You are strictly  prohibited from using any  source other than the  text and the
lectures when  working on this lab, except for the bonus  part. While discussion
between yourselves is encouraged,  you  are strictly  forbidden  from  acquiring
source code  from  the internet or from  any other  external resource or  person
besides  the instructor.  Copying is  strictly forbidden.  Disciplinary  actions
range from  a lab  grade penalty  to  failing the course or more.

EOF
        echo -n "Do you agree with these rules (type y or n)? "
        if read -q; then
            touch .agreement-accepted
            echo ""
        else
            echo ""
            echo "Can't start the driver without accepting rules."
            exit 4
        fi
    fi
}

check_exe () {
    # Make sure we have an existing executable proxy
    if [ ! -x $1 ]; then 
        echo "Error: executable file not found. Please run make and try again."
        exit 4
    fi
    
    if ( cd ../src/; make --recon | grep -q gcc ); then
        echo "WARNING: the sources are more recent than the executable.  Perhaps run make?"
        wait_a_bit
    fi
}
