#include <iostream>
#include <iomanip>
#include <set>
#include <boost/process.hpp>
#include <fstream>


namespace bp = boost::process;

void usage (const char* progname) {
  std::cerr << "usage: " << progname
            << " DICT_EXE TRACE DATA_PATH\n"
            << "Run DICT_EXE and send the commands in TRACE, checking "
            << "the results are correct.\n"
            << "Lines starting with ! in TRACE are passed as argument to DICT_EXE,\n"
            << "each of them prefixed by DATA_PATH.\n";
  exit (1);
}


struct iopstreams {
    bp::opstream in;
    bp::ipstream out;
};

#define fail(msg) do { std::cerr << msg << std::endl; throw 1; } while (0)

bool getline_enforce (std::istream& is, std::string& str) {
  if (std::getline (is, str))
    return true;
  fail ("premature EOF");
  return false;
}

void check_dumps (const std::string& context,
                  std::istream& f1, std::istream& f2, bool end_dump_f1) {
  std::string line;
  std::set<std::string> dump;
  auto getlinef1 = [&] () -> bool {
    if (end_dump_f1)
      return getline_enforce (f1, line);
    else
      return (bool) std::getline (f1, line);
  };

  while (getlinef1 () && (not end_dump_f1 or line != "END_DUMP"))
    if (not dump.insert (line).second)
      fail (context << " command: duplicate in dump");

  while (getline_enforce (f2, line) && line != "END_DUMP")
    if (dump.erase (line) != 1)
      fail (context << " command: expected " << line << " in dump");

  if (not dump.empty ())
    fail (context << " command: too many elements in dump");
}

void simulate (iopstreams& dict_io, std::ifstream& trace, const std::string& cmd,
               const std::string& args = "") {
  std::string dict_line, trace_line;
  auto gobble_prompt = [&] () {
    char prompt[2];
    dict_io.out.read (prompt, 2);
  };

  gobble_prompt ();
  dict_io.in << cmd << (args.empty () ? "" : " ") << args << std::endl;

  auto check_nextline_equal = [&] () {
    getline_enforce (dict_io.out, dict_line);
    getline_enforce (trace, trace_line);
    if (trace_line != dict_line)
      fail (cmd << " command: expected " << cmd << " mapped to " << trace_line
            << ", got " << dict_line);
  };

  const std::unordered_map<std::string, std::function<void()>> commands {
    {"get", check_nextline_equal },
    // put, del, clr are noop.
    {"siz", check_nextline_equal },
    {"dmp", [&] () {
      // Check BEGIN_DUMP
      check_nextline_equal ();
      check_dumps ("dmp", dict_io.out, trace, true);
    } },
    {"ldf", [&] () {
      getline_enforce (dict_io.out, dict_line);
      if (dict_line != "LOADED")
        fail ("expected 'LOADED' after ldf, got " << dict_line);
      getline_enforce (trace, trace_line); // BEGIN_DUMP
      int all_items = 0;
      while (getline_enforce (trace, trace_line) && trace_line != "END_DUMP") {
        ++all_items;
        auto colon = trace_line.find (':');
        auto key = trace_line.substr (0, colon);
        auto value = trace_line.substr (colon + 1);
        gobble_prompt ();
        dict_io.in << "get " << key << std::endl;
        getline_enforce (dict_io.out, dict_line);
        if (dict_line != value)
          fail ("after ldf, expected " << key << " mapped to " << value
                << ", got " << dict_line);
      }
      gobble_prompt ();
      dict_io.in << "siz" << std::endl;
      getline_enforce (dict_io.out, dict_line);
      if (dict_line != std::to_string (all_items))
        fail ("after ldf, wrong number of elements.");
    } },
    {"svf", [&] () {
      getline_enforce (dict_io.out, dict_line);
      if (dict_line != "SAVED")
        fail ("expected 'SAVED' after svf, got " << dict_line);
      std::ifstream saved_file (args, std::ios::binary);
      getline_enforce (trace, trace_line);  // BEGIN_DUMP
      check_dumps ("svf", saved_file, trace, false);
    } } };

  for (auto& [name, fun] : commands)
    if (name == cmd) {
      fun ();
      return;
    }
}

int main (int argc, char** argv) {
  if (argc == 3)
    usage (argv[0]);

  std::ifstream trace (argv[2], std::ios::binary);
  if (not trace.is_open ()) {
    std::cerr << "cannot open " << argv[2] << std::endl;
    exit (2);
  }

  std::string line;
  std::string extra_args = "";
  while (std::getline (trace, line) && line[0] == '!')
    extra_args = extra_args + " " + argv[3] + "/" + line.substr (1, std::string::npos);

  iopstreams dict_io;
  bp::child  dict ("stdbuf -o0 valgrind -q --error-exitcode=18 --exit-on-first-error=yes "
                   + std::string (argv[1]) + extra_args,
                   bp::std_in < dict_io.in, bp::std_out > dict_io.out);
  if (not dict.running ())
      std::cerr << "cannot start " << argv[1] << std::endl;
  do {
    try {
      if (line[3] == ' ')
        simulate (dict_io, trace, line.substr (0, 3), line.substr (4, std::string::npos));
      else
        simulate (dict_io, trace, line);
    }
    catch (int n) {
      dict_io.in.pipe ().close ();
      dict.wait ();
      exit (dict.exit_code () ? dict.exit_code () : 1);
    }
  } while (std::getline (trace, line));
}
