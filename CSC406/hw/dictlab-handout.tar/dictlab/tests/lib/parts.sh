#!/bin/zsh -f

grade_part () {
    echopart "* PART $1"

    ntests=0
    npass=0

    for f in $GRADING_FILES_DIR/traces/$TESTTYPE-P$1*.log; do
        (( ntests++ ))
        [[ $f =~ -(..).txt ]]
        num=$match[1]
        extra_args=$(sed -n "s@^!@$GRADING_FILES_DIR/@p; 10q" $f | tr '\n' ' ')
        echo -n "[--] $DICT < ${f/log/txt} $extra_args\r"
        rettxt=$(timeout $TIMEOUT lib/test-file $DICT $f $GRADING_FILES_DIR/ 2>&1)
        ret=$?
        case $ret; in
            0)   echook
                 (( npass++ ))
                 ;;
            18)  echomm
                 ;;
            124) echoto
                 ;;
            *)   echoko
                 ;;
        esac
        [[ $rettxt ]] && echoindent 5 "$rettxt"
        (( ret == 18 )) && echoindent 5 "Run with valgrind to trigger this error."
    done

    if (( $1 >= 2 )); then
        ## Use the last trace to check for memory leaks.
        (( potential_score_leak = ntests / 4 ))
        (( ntests += potential_score_leak ))
        echo -n "[--] Checking memory leaks on previous test with valgrind\r"
        if (( ret == 0 )); then
            valgrind $DICT < ${f/log/txt} ${(@s/ /)extra_args} > /dev/null |& grep -q 'LEAK'
            if (( $? != 0 )); then
                echook
                (( npass += potential_score_leak ))
            else
                echoko
                echoindent 5 "valgrind found memory leaks while running"
                echo "     $ valgrind $DICT < ${f/log/txt} $extra_args"
            fi
        else
            echoko
            echoindent 5 'cannot run valgrind on previous test since it failed'
        fi
    fi
    (( score[$1] = npass * 100 / ntests ))
    (( total_score += score[$1], out_of += 100 ))


    
    echoscore "PART $1" "$score[$1] / 100"
}

grade_bonus () {
    echopart "* BONUS"

    local TIMEFMT='%U'
    float all_time
    (( ntests = 0 ))
    for f in $GRADING_FILES_DIR/traces/bonus-*.txt; do
        (( ++ntests ))
        echo -n "Timing $f... "
        v=$({time timeout $TIMEOUT $DICT < $f > /dev/null } 2>&1)
        case $?; in
            124) echoko "TIMEOUT.";;
            *)   echo $v;;
        esac
        float this_time=$v[1,-2] # Remove s from 1.02s
        (( all_time += this_time ))
    done
    printf "Total time: %.2f\n" $all_time
    float bonus_score
    ## Compute the bonus score; the 0.9 factor is because time reports slightly less
    ## than TIMEOUT when timing out.
    (( bonus_score = BONUS_POINTS *
       ( all_time - ntests * TIMEOUT * 0.9 ) / (ntests * (GOOD_PERF - TIMEOUT)) ))
    

    if (( bonus_score > BONUS_POINTS )); then
        (( bonus_score = BONUS_POINTS ))
    fi
    if (( bonus_score < 0 )); then
        (( bonus_score = 0 ))
    fi
    (( total_score += bonus_score ))
    echoscore "BONUS" "$(printf "%.0f / %d\n" $bonus_score $BONUS_POINTS)"
}
