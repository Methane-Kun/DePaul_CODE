if [[ $HOST == 'cdmcsclpprd01.dpu.depaul.edu' ]]; then
    GRADING_FILES_DIR=/home/lperkovi/public/dictlab-grading
else
    GRADING_FILES_DIR=.
fi
