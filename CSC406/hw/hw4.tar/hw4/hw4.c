
// Homework 4

  // Problem 3.62
  // Fill in the switch statement below

typedef enum { MODE_A, MODE_B, MODE_C, MODE_D, MODE_E } mode_t;


long switch3 (long *p1, long*p2, mode_t action)
{

  long result = 0;
  switch (action) {

  case MODE_A:


    

  case MODE_B:

   


  case MODE_C:



    
  case MODE_D:




  case MODE_E:





  default:

    ;

  }

  return result;

}





// Problem 3.65

/*

A.






B.







C.





 */


