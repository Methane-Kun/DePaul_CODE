#include <stdio.h>
#include <limits.h>

void ranges() {
  // implement this
}

int funSum1(int n) {
  int res = 0;
  // complete this
  return res;
}

int funSum2(int n) {
  int res = 0;
  // complete this
  return res;
}

int funSum3(int n) {
  int res = 0;
  // complete this
  return res;
}

int funSum4(int n) {
  // complete this
}


void types() {
  // implement this
}


// test code; do not modify
int main() {

  ranges();

  printf("funSum1(20) = %d\n", funSum1(20));
  printf("funSum2(20) = %d\n", funSum2(20));
  printf("funSum3(20) = %d\n", funSum3(20));
  printf("funSum4(20) = %d\n", funSum4(20));
  printf("\n");

  types();

  return 0;
}
