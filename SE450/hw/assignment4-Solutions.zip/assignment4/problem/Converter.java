/*
 *
 *  * Copyright (c) 2022.
 *  * Vahid Alizadeh
 *  * Object-oriented Software Development
 *  * DePaul University
 *
 */

package assignment4.problem;

public class Converter {


	public static void main(String[] args) {
		ConverterGUI ui = new ConverterGUI();

	}

	//You can add method (s) if necessary here or in a separate class to implement the converter logic using the patterns
	//static Convert(..) method?
	// Instantiating Handlers and setSuccessors?
	//Decorators?
}
