/*
 *
 *  * Copyright (c) 2022.
 *  * Vahid Alizadeh
 *  * Object-oriented Software Development
 *  * DePaul University
 *
 */

package assignment2.solution.exercise4;

public class Album extends Item {
    public Album(String ismn, String title, String artist, int price, String genre) {
        super(ismn, title, artist, price, genre);
    }
}
