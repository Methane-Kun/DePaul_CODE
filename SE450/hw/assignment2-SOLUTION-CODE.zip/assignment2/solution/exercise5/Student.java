/*
 *
 *  * Copyright (c) 2022.
 *  * Vahid Alizadeh
 *  * Object-oriented Software Development
 *  * DePaul University
 *
 */

package assignment2.solution.exercise5;

public class Student {
    private String name;

    Student() {
    }
    public String getName() {
        return name;
    }

    public void setName( String n) {
        name=n;
    }
}