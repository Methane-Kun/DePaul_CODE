/*
 *
 *  * Copyright (c) 2022.
 *  * Vahid Alizadeh
 *  * Object-oriented Software Development
 *  * DePaul University
 *
 */

package assignment1.exercise7;

public class SquareTest {
    public static void main(String args[]) {
        Square square = new Square(5);
        square.printDetails();
    }
}