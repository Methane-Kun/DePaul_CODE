/*
 *
 *  * Copyright (c) 2022.
 *  * Vahid Alizadeh
 *  * Object-oriented Software Development
 *  * DePaul University
 *
 */

package assignment1.exercise7;

public class RectangleTest {
    public static void main(String args[]) {
        Rectangle rectangle1 = new Rectangle(5,6);
        Rectangle rectangle2 = new Rectangle(8,9);
        rectangle1.printDetails();
        rectangle2.printDetails();
    }
}
