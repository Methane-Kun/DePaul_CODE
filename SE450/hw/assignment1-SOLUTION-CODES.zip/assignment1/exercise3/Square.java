/*
 *
 *  * Copyright (c) 2022.
 *  * Vahid Alizadeh
 *  * Object-oriented Software Development
 *  * DePaul University
 *
 */

package assignment1.exercise3;

public class Square {
    public int side;
    public Square(int l) {
        side = l;
    }
    public int perimeter() {
        int perimeter = side * 4;
        return perimeter;
    }
    public int area() {
        int area = side * side;
        return area;
    }
}
