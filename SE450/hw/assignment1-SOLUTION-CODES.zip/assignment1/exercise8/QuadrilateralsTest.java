/*
 *
 *  * Copyright (c) 2022.
 *  * Vahid Alizadeh
 *  * Object-oriented Software Development
 *  * DePaul University
 *
 */

package assignment1.exercise8;

public class QuadrilateralsTest {
    public static void main(String args[]) {
        Square square = new Square(5);
        square.printDetails();
        Rectangle rectangle = new Rectangle(5,6);
        rectangle.printDetails();
    }
}
