/*
 * @Descripttion: 
 * @version: 
 * @Author: Kun Shan
 * @Date: 2023-01-11 19:33:44
 * @LastEditors: Kun Shan
 * @LastEditTime: 2023-01-15 15:50:18
 * @FilePath: /codes/assign1/header.h
 */
/*-------------------------------------------------------------------------*
 *---									---*
 *---		header.h						---*
 *---									---*
 *---	----	----	----	----	----	----	----	----	---*
 *---									---*
 *---	Version 1a					Joseph Phillips	---*
 *---									---*
 *-------------------------------------------------------------------------*/

#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>

// YOUR CODE HERE


extern void insertionSort();
extern void quickSort();
extern int strLen;
extern void swap();